## Writing inodes from the file system 

Self study